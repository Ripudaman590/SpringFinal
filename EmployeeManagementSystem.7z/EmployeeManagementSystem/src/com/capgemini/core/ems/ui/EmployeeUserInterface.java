package com.capgemini.core.ems.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.capgemini.core.ems.beams.Employee;
import com.capgemini.core.ems.dao.IEmployeeDAO;
import com.capgemini.core.ems.exceptions.EmployeeExceptions;
import com.capgemini.core.ems.services.EmployeeSeriveImpl;
import com.capgemini.core.ems.services.IEmployeeService;

public class EmployeeUserInterface 
{
	//lose coupling
	
	IEmployeeService empService = new EmployeeSeriveImpl();
	Scanner console = new Scanner(System.in);
	public void emsOperations()
	{
		int choice = 0 ;
		
		System.out.println("1) ADD Employee");
		System.out.println("2) Get Employee");
		System.out.println("3) Update Employee");
		System.out.println("4) Remove Employee");
		System.out.println("5) View All Employee");
		System.out.println("6) Exit Application");
		
		System.out.println("Enter your choice ");
		
		choice = console.nextInt();
		
		switch (choice) {
		case 1:
			System.out.println("\n\n\n\n\n\n");
			
//			System.out.println("Enter Employee ID : ");
//			int id = console.nextInt();
			
			System.out.println("Enter Employee Name : ");
			String name = console.next();
			
			System.out.println("Enter Employee Salary : ");
			double salary = console.nextDouble();
			
			System.out.println("Enter Employee Date of Joining (yyyy/mm/dd)");
			String strDate = console.next();
			
			String arr[] = strDate.split("/");
			
			int yyyy = Integer.parseInt(arr[0]);
			int mm = Integer.parseInt(arr[1]);
			int dd = Integer.parseInt(arr[2]);
			
			LocalDate dateofJoining = LocalDate.of(yyyy, mm, dd);
			
			//instantiating and initializing employee object
			Employee employee = new Employee();
			
//			employee.setId( id );
			employee.setName( name );
			employee.setSalary( salary );
			employee.setDateOfJoining(dateofJoining);
			
			//Pass employee details (Employee object) to service layer
			
			try {
				int empId = empService.addEmployee( employee );
				
				System.out.println("Employee added sucessfully ID = " + empId);
			} 
			catch (EmployeeExceptions e) 
			{
				e.printStackTrace();
				System.out.println("Something went wrong while adding employee. Exception : " + e.getMessage());
			}
			
		break;
		
		case 2:
			System.out.println("\n\n\n");
			
			System.out.println("Enter employee id");
			
			
			int id = console.nextInt();
			
			try 
			{
				Employee emp1 = empService.getEmployee( id );
				
				System.out.println("ID : " + emp1.getId());
				
				System.out.println("NAME : " + emp1.getName());
			
				System.out.println("SALARy : " + emp1.getSalary());
				
				System.out.println("Doj : " + emp1.getDateOfJoining());
				
				System.out.println("\n\n\n");
			} 
			catch (EmployeeExceptions e1) 
			{

				e1.printStackTrace();
				System.out.println( "Something went wrong. Exception : " + e1.getMessage());
			}
	
		break;
		
		case 3:
			System.out.println("\n\n\n");
			
			System.out.println("Enter employee id");
			
			id = console.nextInt();
			
			try 
			{
				Employee emp1 = empService.getEmployee( id );
				
				System.out.println("ID : " + emp1.getId());		
				System.out.println("NAME : " + emp1.getName());
				System.out.println("SALARy : " + emp1.getSalary());
				System.out.println("Doj : " + emp1.getDateOfJoining());
				
				System.out.println("Do you want to update name ? (y/n)");
				char reply = console.next().charAt(0);
				if (reply == 'y' || reply == 'Y') 
				{
					System.out.println("Old name " + emp1.getName());
					System.out.println("Provide New name : " );
					emp1.setName(console.next());
				}
				
				System.out.println("Do you want to update Salary ? (y/n)");
				reply = console.next().charAt(0);
				if (reply == 'y' || reply == 'Y') 
				{
					System.out.println("Old salary " + emp1.getSalary());
					System.out.println("Provide New salary : " );
					emp1.setSalary(console.nextDouble());
				}
				System.out.println("Do you want to update Doj ? (y/n)");
				reply = console.next().charAt(0);
				if (reply == 'y' || reply == 'Y') 
				{
					System.out.println("Old Doj " + emp1.getDateOfJoining());
					System.out.println("Provide New Doj : " );
					
					strDate = console.next();
					
					arr = strDate.split("/");
					
					yyyy = Integer.parseInt(arr[0]);
					mm = Integer.parseInt(arr[1]);
					dd = Integer.parseInt(arr[2]);
					
					dateofJoining = LocalDate.of(yyyy, mm, dd);
					
					emp1.setDateOfJoining(dateofJoining);
				}
				//update in datbase
				empService.UpdateEmployee(emp1);
				
				System.out.println("employee with " + emp1.getId() + "updated sucessfully");
				
				System.out.println("\n\n\n");
			} 
			catch (EmployeeExceptions e1) 
			{

				e1.printStackTrace();
				System.out.println( "Something went wrong. Exception : " + e1.getMessage());
			}
			
			
		break;
		
		case 4:
			System.out.println("\n\n\n");
			
			System.out.println("Enter employee id");
			
			id = console.nextInt();
			
			try
			{
				empService.removeEmployee(id);
				System.out.println("Employee removed : " + id );
			} 
			catch (EmployeeExceptions e1)
			{
				e1.printStackTrace();
				System.out.println( "Something went wrong. Exception : " + e1.getMessage());

			}
			
			
			
		break;
		
		case 5:
			
			try {
				ArrayList<Employee> emps = empService.getEmployees();
				Iterator<Employee> it = emps.iterator();
				
				while (it.hasNext()) 
				{
					Employee emp = it.next();
					
					System.out.println("\n\n");
					
					System.out.println("ID : " + emp.getId());
					
					System.out.println("NAME : " + emp.getName());
				
					System.out.println("SALARy : " + emp.getSalary());
					
					System.out.println("Date of Joining : " + emp.getDateOfJoining());
				}
				
				
				System.out.println("\n\n");
				
				console.next();
				
				} 
			catch (EmployeeExceptions e) 
				{
				e.printStackTrace();
				System.out.println("Something went wrong Exception : " + e.getMessage());
				}
			
		break;
		case 6:
			System.exit(0);
		break;

		default:
			System.out.println("Wrong input. Please select from given options");
		break;
		}
		
		
		
	}
}
