package com.capgemini.core.ems.dao;

import java.util.ArrayList;

import com.capgemini.core.ems.beams.Employee;
import com.capgemini.core.ems.exceptions.EmployeeExceptions;

public interface IEmployeeDAO
{
	public int addEmployee(Employee employee) throws EmployeeExceptions;
	
	public Employee getEmployee(int id) throws EmployeeExceptions;
	
	public void UpdateEmployee (Employee emplyee) throws EmployeeExceptions;
	
	public void removeEmployee(int id) throws EmployeeExceptions;
	
	public ArrayList<Employee> getEmployees() throws EmployeeExceptions ;

}
