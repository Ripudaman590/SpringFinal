package com.capgemini.core.ems.dao;

import java.util.ArrayList;

import com.capgemini.core.ems.beams.Employee;
import com.capgemini.core.ems.exceptions.EmployeeExceptions;

public class EmployeeDaoImpl implements IEmployeeDAO
{
	private ArrayList<Employee> employeeDB = new ArrayList<>();

	private int generateEmployeeID()
	{
		return (int)(Math.random() * 1000);
	}
	
	
	@Override
	public int addEmployee(Employee employee) throws EmployeeExceptions 
	{
		employee.setId(generateEmployeeID());
		
		if ( employeeDB.contains(employee)) 
		{
			throw new EmployeeExceptions("Employee exists with id " + employee.getId());
		}
		
		employeeDB.add(employee);
		
		return employee.getId();
		
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeExceptions 
	{
		Employee emp = new Employee();
		emp.setId(id);
		
		if(employeeDB.contains( emp ))
		{
			int index = employeeDB.indexOf( emp );
			
			emp = employeeDB.get( index );
		}
		else
		{
			throw new EmployeeExceptions("Employee not found with ID " + id	);
		}
		
		return emp ;
	}

	@Override
	public void UpdateEmployee(Employee employee) throws EmployeeExceptions
	{
		
		int index = employeeDB.indexOf(employee);
		
		employeeDB.remove(index);
		
		employeeDB.add(index , employee);
		
	}

	@Override
	public void removeEmployee(int id) throws EmployeeExceptions 
	{
		Employee emp = new Employee();
		emp.setId(id);
		
		if(employeeDB.contains( emp ))
		{
			employeeDB.remove(emp);
		}
		else
		{
			throw new EmployeeExceptions("Employee not found with ID " + id	);
		}
		
	}

	@Override
	public ArrayList<Employee> getEmployees() throws EmployeeExceptions 
	{
		if (employeeDB.isEmpty()) {
			throw new EmployeeExceptions("No Employees in Database ");
			
		}
		
		return employeeDB;
	}
	
}
