package com.capgemini.core.ems.services;

import java.util.ArrayList;

import com.capgemini.core.ems.beams.Employee;
import com.capgemini.core.ems.dao.EmployeeDaoImpl;
import com.capgemini.core.ems.dao.IEmployeeDAO;
import com.capgemini.core.ems.exceptions.EmployeeExceptions;

public class EmployeeSeriveImpl implements IEmployeeService {
	
	//loose coupling
	
	IEmployeeDAO empDAO = new EmployeeDaoImpl();
	
	
	@Override
	public int addEmployee(Employee employee) throws EmployeeExceptions {
		return empDAO.addEmployee(employee);
		
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeExceptions {
		return empDAO.getEmployee(id);
	}

	@Override
	public void UpdateEmployee(Employee employee) throws EmployeeExceptions {
		empDAO.UpdateEmployee(employee);
	}

	@Override
	public Employee removeEmployee(int id) throws EmployeeExceptions {
		empDAO.removeEmployee(id);
		return null;
	}

	@Override
	public ArrayList<Employee> getEmployees() throws EmployeeExceptions {
		return empDAO.getEmployees();
	}

}
