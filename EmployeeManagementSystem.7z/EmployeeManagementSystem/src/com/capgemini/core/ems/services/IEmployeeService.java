package com.capgemini.core.ems.services;

import java.util.ArrayList;

import com.capgemini.core.ems.beams.Employee;
import com.capgemini.core.ems.exceptions.EmployeeExceptions;

public interface IEmployeeService
{
	public int addEmployee(Employee employee) throws EmployeeExceptions;
	
	public Employee getEmployee(int id) throws EmployeeExceptions;
	
	public void UpdateEmployee (Employee employee) throws EmployeeExceptions;
	
	public Employee removeEmployee(int id) throws EmployeeExceptions;
	
	public ArrayList<Employee> getEmployees() throws EmployeeExceptions ;
		
}
