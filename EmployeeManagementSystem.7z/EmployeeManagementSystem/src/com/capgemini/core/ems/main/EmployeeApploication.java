package com.capgemini.core.ems.main;

import com.capgemini.core.ems.ui.EmployeeUserInterface;

public class EmployeeApploication {

	public static void main(String[] args) 
	{
		EmployeeUserInterface ui = new EmployeeUserInterface();
		
		
	while(true)
		{
		ui.emsOperations();
		}
	}
}
