package com.cg.cricket.beans;

import java.sql.Date;

public class Cricket 
{
	
	//declaration part
	private int id;
	 private String name;
	  private Date dob;
	  private String country;
	  private String style;
	  private String centuries;
	  private String matches;
	  private String score;
	  
	  //getter setter
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	public String getCenturies() {
		return centuries;
	}
	public void setCenturies(String centuries) {
		this.centuries = centuries;
	}
	public String getMatches() {
		return matches;
	}
	public void setMatches(String matches) {
		this.matches = matches;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	
	//parametrized constructor
	public Cricket(int id, String name, Date dob, String country, String style,
			String centuries, String matches, String score) {
		super();
		this.id = id;
		this.name = name;
		this.dob = dob;
		this.country = country;
		this.style = style;
		this.centuries = centuries;
		this.matches = matches;
		this.score = score;
	}
	
	//to string method
	@Override
	public String toString() {
		return "Cricket [id=" + id + ", name=" + name + ", dob=" + dob
				+ ", country=" + country + ", style=" + style + ", centuries="
				+ centuries + ", matches=" + matches + ", score=" + score + "]";
	}
	
	//default constructor
	public Cricket() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
