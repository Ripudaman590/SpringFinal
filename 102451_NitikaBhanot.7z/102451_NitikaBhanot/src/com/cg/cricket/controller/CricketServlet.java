package com.cg.cricket.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.cricket.beans.Cricket;
import com.cg.cricket.exception.CricketException;
import com.cg.cricket.service.CricketServiceImpl;
import com.cg.cricket.service.ICricketService;



/**
 * Servlet implementation class CricketServlet
 */
@WebServlet("/players")
public class CricketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public CricketServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		String action = request.getParameter("action");
		//Create instance of Service
		ICricketService service = new CricketServiceImpl();
		
		switch(action){
		
		//for adding 
		case "Save Player Data":
			String dob = request.getParameter("dob");
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  //date format
			  
			 Date date=null;
			try {
				date = formatter.parse(dob);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
			 java.sql.Date actDate = new java.sql.Date(date.getTime());
			 
			//code to add employee
			Cricket e1 = new Cricket();
			e1.setName(request.getParameter("name"));
			e1.setDob(actDate);
			e1.setCountry(request.getParameter("country"));
			e1.setStyle(request.getParameter("style"));
			e1.setCenturies(request.getParameter("centuries"));
			e1.setMatches(request.getParameter("matches"));
			e1.setScore(request.getParameter("score"));
			
			//save using service
			try{
				int id= service.add(e1);
				e1.setId(id);
			}catch(CricketException ex){
				request.getSession().setAttribute("error", ex.getMessage());
			}
			//store error/success message in SESSION
			request.getSession().setAttribute("crc", e1);
			
			RequestDispatcher view2 = request.getRequestDispatcher("InsertSuccess.jsp");  //providing link
			view2.forward(request, response);
			return;
		
			
			//for viewing
	case "list":
		try{
		//code to list employees from service
		List<Cricket> emps=service.getAll();
		//add list into SESSION
		request.getSession().setAttribute("crcList", emps);
		//forward request to "list.jsp"
		}catch(CricketException ex){
			request.getSession().setAttribute("error", ex.getMessage());
		}
		RequestDispatcher view1 = request.getRequestDispatcher("list.jsp");   //providing link
		view1.forward(request, response);
		return;
		
		}
	
		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		doGet(request, response);
		
	}

}
