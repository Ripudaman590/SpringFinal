package com.cg.cricket.dao;

import java.util.List;

import com.cg.cricket.beans.Cricket;
import com.cg.cricket.exception.CricketException;

public interface ICricketDao 
{
	int add(Cricket e) throws CricketException;
	List<Cricket> getAll() throws CricketException;
}
