package com.cg.cricket.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import javax.naming.NamingException;

import com.cg.cricket.beans.Cricket;
import com.cg.cricket.exception.CricketException;
import com.cg.cricket.util.DbUtil;


public class CricketDaoImpl implements ICricketDao{

	//query for inserting data into database
	private static final String INSERT_QUERY
	="INSERT into cricket_score(player_id,player_name,dob,country,batting_style,centuries,matches,total_run_score) "+  
		"   values(player_seq.nextval, ?,?,?,?,?,?,?)";

	
	//query for fetching data from data base
	private static final String GET_ALL_QUERY
	="select player_id,player_name,dob,country,batting_style,centuries,matches,total_run_score from cricket_score";
	
	
	@Override
	public int add(Cricket e) throws CricketException {
		try{
			Connection con = DbUtil.obtainConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);  //calls insert query   
			ps.setString(1,e.getName());
			ps.setDate(2, e.getDob());
			ps.setString(3,e.getCountry());
			ps.setString(4,e.getStyle());
			ps.setString(5,e.getCenturies());
			ps.setString(6,e.getMatches());
			ps.setString(7,e.getScore());
			
			
			ps.executeUpdate();
			int id =0;
			//Get generated Primary key:
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select player_seq.currval from dual");   //calling sequence
			if(rs.next()){				
				id = rs.getInt(1);
				System.out.println("SEQ value "+id);
			}
			con.close();
			return id;
		}catch(NamingException | SQLException ex){
			throw new CricketException("Unable to save, "+ex.getMessage());
		}
		

	}

	@Override
	public List<Cricket> getAll() throws CricketException {
		try{
			Connection con = DbUtil.obtainConnection();
			PreparedStatement ps = con.prepareStatement(GET_ALL_QUERY);   //calling get all query
			ResultSet rs = ps.executeQuery();
			//Create EMPTY list
			List<Cricket> emps = new LinkedList<>();
			//Get ONE record at a time
			while(rs.next()){
				Cricket e = new Cricket();
				//Store ALL values into Cricket Object
				//"e" is now D.T.O.
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setDob(rs.getDate(3));
				e.setCountry(rs.getString(4));
				e.setStyle(rs.getString(5));
				e.setCenturies(rs.getString(6));
				e.setMatches(rs.getString(7));
				e.setScore(rs.getString(8));
				
				//Add DTO into LIST
				emps.add(e);
			}
			return emps;
			
			//return LIST
			
		}catch(NamingException | SQLException ex){
			throw new CricketException("Unable to fetch records, "+ex.getMessage());
		}
		
	}

	}

	
	
	
