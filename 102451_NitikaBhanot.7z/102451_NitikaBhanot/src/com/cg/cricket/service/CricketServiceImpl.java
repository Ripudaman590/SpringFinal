package com.cg.cricket.service;

import java.util.List;

import com.cg.cricket.beans.Cricket;
import com.cg.cricket.dao.CricketDaoImpl;
import com.cg.cricket.dao.ICricketDao;
import com.cg.cricket.exception.CricketException;


public class CricketServiceImpl implements ICricketService
{
	private ICricketDao dao = null;

	public CricketServiceImpl() {
		dao = new CricketDaoImpl();
	}

	@Override
	public int add(Cricket e) throws CricketException {
		// TODO Auto-generated method stub
		return dao.add(e);  //returning cricket
	}

	@Override
	public List<Cricket> getAll() throws CricketException {
		// TODO Auto-generated method stub
		return dao.getAll();   //returning data 
	}

}
