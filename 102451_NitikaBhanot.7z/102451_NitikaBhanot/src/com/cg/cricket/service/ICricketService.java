package com.cg.cricket.service;

import java.util.List;

import com.cg.cricket.beans.Cricket;
import com.cg.cricket.exception.CricketException;

public interface ICricketService 
{
	int add(Cricket e) throws CricketException;
	List<Cricket> getAll() throws CricketException;
}
