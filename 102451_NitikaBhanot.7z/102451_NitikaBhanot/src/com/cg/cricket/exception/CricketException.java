package com.cg.cricket.exception;

public class CricketException extends Exception
{
	

	public CricketException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CricketException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
